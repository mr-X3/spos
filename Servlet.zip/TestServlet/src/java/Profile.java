import java.sql.*;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class Profile extends HttpServlet
{
public void service(HttpServletRequest req,HttpServletResponse resp)
throws ServletException,IOException
{
PrintWriter pw=resp.getWriter();
pw.println("<html><body>");
String id=req.getParameter("id");

try
{
 String dbURL = "jdbc:mysql://localhost:3306/bookstore";

   String username = "root";
   String password = "";
   Class.forName("com.mysql.jdbc.Driver"); //load driver
   Connection con2 = DriverManager.getConnection(dbURL, username, password);
   String sqlstmt="select * from login where id='"+id+"'";
   Statement stmt = con2.createStatement();
  
ResultSet rs=stmt.executeQuery(sqlstmt);
int flag=0;
pw.println("<br><br><br>");
while(rs.next())
{
pw.println("<div align=\"center\">");
pw.println("NAME :"+rs.getString(1)+"<br>");
pw.println("ADDRESS :"+rs.getString(2)+"<br>");
pw.println("PHONE NO :"+rs.getString(3)+"<br>");
pw.println("</div>");
flag=1;
}if(flag==0)
{
pw.println("<br><br>SORRY INVALID ID TRY AGAIN ID<br><br>");
pw.println("<a href=\"Profile.html\">press HERE to RETRY</a>");
}
pw.println("</body></html>");
}
catch(Exception e)
{
resp.sendError(500,e.toString());
}
}
}
