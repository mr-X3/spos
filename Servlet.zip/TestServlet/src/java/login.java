/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.sql.*;
import java.io.*;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Vishal
 */
@WebServlet(urlPatterns = {
 "/login"
})
public class login extends HttpServlet {

 /**
  * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
  * methods.
  *
  * @param request servlet request
  * @param response servlet response
  * @throws ServletException if a servlet-specific error occurs
  * @throws IOException if an I/O error occurs
  */
 protected void service(HttpServletRequest request, HttpServletResponse response)
 throws ServletException, IOException {
  PrintWriter pw = response.getWriter();
 
  
  
  String id = request.getParameter("id");
  String pwd = request.getParameter("pwd");
  String s1 = "", s2 = "";

  try {

   String dbURL = "jdbc:mysql://localhost:3306/bookstore";

   String username = "root";
   String password = "";



   Class.forName("com.mysql.jdbc.Driver"); //load driver

   Connection con2 = DriverManager.getConnection(dbURL, username, password);
   String sqlstmt = "select * from login";
   Statement stmt = con2.createStatement();
   ResultSet rs = stmt.executeQuery(sqlstmt);
   int flag = 0;
   while (rs.next()) {
    s1 = rs.getString(1);
    s2 = rs.getString(2);
   }
   if (id.equals(s1) && pwd.equals(s2)) {
    flag = 1;
   }
   if (flag == 0) {
    pw.println("<br><br>SORRY INVALID ID TRY AGAIN ID<br><br>");
    pw.println("<a href=\"login.html\">press LOGIN to RETRY</a>");
   } else {
    pw.println("<br><br>WELCOME TO " + id.toUpperCase() + "<br><br>");
    pw.println("<h3><ul>");
    pw.println("<li><a href=\"Profile.html\"><fontcolor=\"black\">USER PROFILE</font></a></li><br><br>");
    pw.println("<li><a href=\"Catalog.html\"><fontcolor=\"black\">BOOKSCATALOG</font></a></li><br><br>");
    pw.println("<li><a href=\"order.html\"> <fontcolor=\"black\">ORDERCONFIRMATION</font></a></li></ul><br><br>");
   }
   pw.println("</body></html>");
  } catch (Exception e) {
   response.sendError(500, e.toString());
  }

 }
}
