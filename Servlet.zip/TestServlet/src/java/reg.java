import java.sql.*;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
public class reg extends HttpServlet
{
    
public void service(HttpServletRequest req, HttpServletResponse resp)
throws ServletException,IOException

{
PrintWriter pw=resp.getWriter();
resp.setContentType("text/html");
pw.println("<html><body>");
String name=req.getParameter("name");
String addr=req.getParameter("addr");
String phno=req.getParameter("phno");
String id1=req.getParameter("id");
String pwd1=req.getParameter("pwd");

try
{
String dbURL = "jdbc:mysql://localhost:3306/bookstore";
String username="root";
String password="";
Class.forName("com.mysql.jdbc.Driver");//load driver
Connection con2 = DriverManager.getConnection(dbURL, username, password);
Statement stmt=con2.createStatement();
String sqlstmt="select * from login";
ResultSet rs=stmt.executeQuery(sqlstmt);
int flag=0;
while(rs.next())
{
if(id1.equals(rs.getString(4))&&pwd1.equals(rs.getString(5)))
{
flag=1;
}
}
if(flag==1)
{
pw.println("<br><br>SORRY INVALID ID ALREADY EXITSTRY AGAIN WITH NEW ID<br><br>");
pw.println("<a href=\"reg.html\">press REGISTER to RETRY</a>");
}
else
{
Statement stmt1=con2.createStatement();
stmt1.executeUpdate("insert into login(name,address,phone,id,pwd) values('"+name+"','"+addr+"','"+phno+"','"+id1+"','"+pwd1+"')");
pw.println("<br><br>YOUR DETAILS ARE ENTERED<br><br>");
pw.println("<a href=\"login.html\">press LOGIN to login</a>");
}
pw.println("</body></html>");
}
catch(Exception e)
{
resp.sendError(500,e.toString());
}
}
}
